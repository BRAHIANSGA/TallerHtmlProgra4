function alerta() {
    let cadena= document.getElementById("inputString").value;
    alert(cadena);

}