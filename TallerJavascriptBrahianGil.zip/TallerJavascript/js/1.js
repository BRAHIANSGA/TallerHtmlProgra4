alert("Hola mundo");
alert("soy el primer script");