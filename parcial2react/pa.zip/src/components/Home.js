
import React, { useState, useEffect } from 'react';

const Contador = () => {


  return (
    <div>
      <p>Parcial Brahian Stiven Gil Arias </p>
    </div>
  );
};

export default Contador;
